# 3D SPACE SHOOTER GAME

A Unity 6.3 PC space-combat game project. Open the project with Unity 6000.3.25f1 and open `Assets/_project/Scenes/VoidRunner.unity`.

## Important: external art packs are not included

This public repository intentionally excludes the raw Unity Asset Store packs. The scene still has references to the imported ship prefabs and skybox textures, so those references will be unresolved until you obtain and import the corresponding packs through Unity Hub / My Assets. The project code includes a procedural fallback fighter, but the complete ship and skybox visuals require the imported packs.

- Hi-Rez Spaceships Creator Free Sample — https://assetstore.unity.com/packages/3d/vehicles/space/hi-rez-spaceships-creator-free-sample-153363
- Free SF Fighter — https://assetstore.unity.com/packages/3d/vehicles/space/free-sf-fighter-11711
- SpaceSkies Free — https://assetstore.unity.com/packages/2d/textures-materials/sky/spaceskies-free-80503

Only import packs you have acquired and are permitted to use. This repository does not redistribute their source files. Kenney Sci-Fi Sounds is CC0; its notice is at `Assets/_project/Audio/LICENSE-Kenney-Sci-Fi-Sounds.txt`.

## Run

1. Open this folder in Unity Hub using Unity 6000.3.25f1 (Unity 6.3 LTS).
2. If you have the listed asset packs, import them into the project to restore ship and skybox references.
3. Open `Assets/_project/Scenes/VoidRunner.unity` and press Play.
4. On the animated welcome screen, choose Play, select a world, and launch. Ship Selection and Settings are also available from the hangar.

The selectable worlds are Deep Space, Nebula Galaxy, Mars Orbit, Ice Planet, and Alien Galaxy. Each has its own accent and missile design: LANCE, WRAITH, REDSHIFT, FROSTBURN, or XENO. The game includes enemy fighter AI, asteroid hazards, boss encounters, laser and missile firing, engine trails, impact effects, audio, shields, three lives, scoring, persistent high score, sector progression, pause/resume, restart, and return to hangar. It is a single-player campaign against AI opponents; online multiplayer is not included.

## Controls

- W / A / S / D — steer; mouse position also aims and steers
- Left mouse button or Space — fire plasma cannons
- T — lock the nearest hostile target
- R — launch the selected homing missile at a locked target
- Left Shift — boost
- Esc or P — pause; choose Resume, Restart Mission, or Return to Hangar
- Game Over: R restarts; Esc returns to the hangar

## Project layout

- `Assets/_project/Scenes/` — playable scene
- `Assets/_project/scripts/` — flight controller and game logic
- `Assets/_project/Audio/` — sound effects and Kenney license notice
- `Assets/_project/Materials/` — theme skybox materials (their source cubemaps are in the excluded SpaceSkies pack)
- `Assets/Editor/SpaceShooter/` — scene setup and upgrade tools
- `Screenshots/` — captured hangar, gameplay, and pause views

The runtime interface uses Unity's built-in IMGUI to keep dependencies light. Procedural meshes are used for missiles, asteroids, projectiles, and bursts.

## Build / GitHub

`Assets/_project/Scenes/VoidRunner.unity` is enabled in Build Settings. Build for Windows x86_64 from File > Build Profiles. Unity's `Library`, `Temp`, `Obj`, `Logs`, `Build`, `UserSettings`, and IDE output are excluded by `.gitignore`.

To upload, create or select a public repository, initialize the local project with Git, add the project files, review the staged paths, commit, and push the `main` branch. This repository intentionally omits the Asset Store pack contents; keep them out of public commits unless you have redistribution rights.