using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;

public sealed class SpaceShooterGame : MonoBehaviour
{
    sealed class EnemyState
    {
        public GameObject body;
        public float health;
        public float fireTimer;
        public float speed;
    }

    sealed class ShotState
    {
        public GameObject body;
        public Vector3 velocity;
        public bool playerShot;
        public float life;
    }

    readonly List<EnemyState> enemies = new List<EnemyState>();
    readonly List<ShotState> shots = new List<ShotState>();
    GameObject runtimeRoot;
    GameObject player;
    Material playerMat, enemyMat, accentMat, playerShotMat, enemyShotMat, asteroidMat;
    int score, hull, kills, wave;
    float spawnTimer, fireTimer, hazardTimer, playerHitTimer;
    bool gameOver, paused;
    bool initialized;

    void Awake()
    {
        BuildMaterials();
        ResetGame();
    }

    void Update()
    {
        if (!initialized) return;
        var keyboard = Keyboard.current;
        if (keyboard == null) return;

        if (gameOver)
        {
            if (keyboard.rKey.wasPressedThisFrame) ResetGame();
            return;
        }

        if (keyboard.pKey.wasPressedThisFrame)
        {
            paused = !paused;
            Time.timeScale = paused ? 0f : 1f;
        }
        if (paused) return;

        UpdatePlayer(keyboard);
        UpdateShots();
        UpdateEnemies();
        UpdateHazards();
        UpdateSpawning();
    }

    void UpdatePlayer(Keyboard keyboard)
    {
        var move = Vector2.zero;
        if (keyboard.aKey.isPressed || keyboard.leftArrowKey.isPressed) move.x -= 1f;
        if (keyboard.dKey.isPressed || keyboard.rightArrowKey.isPressed) move.x += 1f;
        if (keyboard.sKey.isPressed || keyboard.downArrowKey.isPressed) move.y -= 1f;
        if (keyboard.wKey.isPressed || keyboard.upArrowKey.isPressed) move.y += 1f;
        if (move.sqrMagnitude > 1f) move.Normalize();

        var p = player.transform.position;
        p.x = Mathf.Clamp(p.x + move.x * 7.2f * Time.deltaTime, 0.85f, 14.15f);
        p.z = Mathf.Clamp(p.z + move.y * 7.2f * Time.deltaTime, 0.85f, 14.15f);
        player.transform.position = p;
        player.transform.rotation = Quaternion.Euler(0f, move.x * 12f, 0f);

        fireTimer -= Time.deltaTime;
        if ((keyboard.spaceKey.isPressed || keyboard.leftCtrlKey.isPressed) && fireTimer <= 0f)
        {
            FirePlayerShot();
            fireTimer = 0.22f;
        }
    }

    void UpdateSpawning()
    {
        spawnTimer -= Time.deltaTime;
        int maxEnemies = Mathf.Min(4 + wave, 9);
        if (spawnTimer <= 0f && enemies.Count < maxEnemies)
        {
            SpawnEnemy();
            spawnTimer = Mathf.Max(1.05f, 2.35f - wave * 0.06f);
        }
        wave = kills / 8 + 1;
    }

    void SpawnEnemy()
    {
        float x = Random.Range(1.8f, 13.2f);
        float z = Random.Range(12.8f, 15.2f);
        if (Random.value < 0.28f)
        {
            x = Random.value < 0.5f ? 1.2f : 13.8f;
            z = Random.Range(7f, 13f);
        }

        var root = new GameObject("Raider Drone");
        root.transform.SetParent(runtimeRoot.transform, true);
        root.transform.position = new Vector3(x, 0.56f, z);
        MakeShipVisual(root.transform, false);
        enemies.Add(new EnemyState
        {
            body = root,
            health = 2f,
            fireTimer = Random.Range(2.2f, 3.4f),
            speed = Random.Range(1.45f, 2.15f) + wave * 0.1f
        });
    }

    void UpdateEnemies()
    {
        for (int i = enemies.Count - 1; i >= 0; i--)
        {
            var e = enemies[i];
            if (e.body == null) { enemies.RemoveAt(i); continue; }
            Vector3 p = e.body.transform.position;
            Vector3 target = player.transform.position;
            float steer = Mathf.Sign(target.x - p.x);
            p.x += steer * Mathf.Min(Mathf.Abs(target.x - p.x), e.speed * 0.3f * Time.deltaTime);
            p.z -= e.speed * Time.deltaTime;
            e.body.transform.position = p;
            e.body.transform.rotation = Quaternion.Euler(0f, 180f - steer * 10f, 0f);

            e.fireTimer -= Time.deltaTime;
            if (e.fireTimer <= 0f && p.z < 13f)
            {
                FireEnemyShot(p + Vector3.down * 0.08f);
                e.fireTimer = Random.Range(2.6f, 3.6f) / Mathf.Min(1.5f, 0.9f + wave * 0.03f);
            }

            if (Vector3.Distance(p, player.transform.position) < 0.82f)
            {
                DamagePlayer(1);
                Destroy(e.body);
                enemies.RemoveAt(i);
                continue;
            }
            if (p.z < 0.4f)
            {
                DamagePlayer(1);
                Destroy(e.body);
                enemies.RemoveAt(i);
            }
        }
    }

    void UpdateShots()
    {
        for (int i = shots.Count - 1; i >= 0; i--)
        {
            var shot = shots[i];
            shot.life -= Time.deltaTime;
            Vector3 p = shot.body.transform.position + shot.velocity * Time.deltaTime;
            shot.body.transform.position = p;
            bool remove = shot.life <= 0f || p.x < -1f || p.x > 17f || p.z < -1f || p.z > 17f;

            if (!remove && shot.playerShot)
            {
                for (int e = enemies.Count - 1; e >= 0; e--)
                {
                    var enemy = enemies[e];
                    if (enemy.body == null || Vector3.Distance(p, enemy.body.transform.position) > 0.62f) continue;
                    enemy.health -= 1f;
                    remove = true;
                    if (enemy.health <= 0f)
                    {
                        Destroy(enemy.body);
                        enemies.RemoveAt(e);
                        score += 100;
                        kills++;
                        SpawnBurst(p, accentMat);
                    }
                    break;
                }
            }
            else if (!remove && !shot.playerShot && Vector3.Distance(p, player.transform.position) < 0.56f)
            {
                DamagePlayer(1);
                remove = true;
            }

            if (remove)
            {
                Destroy(shot.body);
                shots.RemoveAt(i);
            }
        }
    }

    void UpdateHazards()
    {
        hazardTimer -= Time.deltaTime;
        if (hazardTimer > 0f) return;
        Vector3 p = player.transform.position;
        bool onHazardBand = p.x >= 4.7f && p.x <= 10.3f &&
                            (Mathf.Abs(p.z - 4.5f) < 0.48f || Mathf.Abs(p.z - 11.5f) < 0.48f);
        if (onHazardBand)
        {
            DamagePlayer(1);
            hazardTimer = 0.75f;
        }
    }

    void FirePlayerShot()
    {
        Vector3 p = player.transform.position + new Vector3(0f, 0.08f, 0.9f);
        shots.Add(CreateShot(p, Vector3.forward * 12f, true, playerShotMat));
        score += 0;
    }

    void FireEnemyShot(Vector3 position)
    {
        Vector3 direction = (player.transform.position - position).normalized;
        direction.y = 0f;
        shots.Add(CreateShot(position, direction.normalized * 5.8f, false, enemyShotMat));
    }

    ShotState CreateShot(Vector3 position, Vector3 velocity, bool friendly, Material material)
    {
        var shot = GameObject.CreatePrimitive(PrimitiveType.Sphere);
        shot.name = friendly ? "Pulse Bolt" : "Hostile Bolt";
        shot.transform.SetParent(runtimeRoot.transform, true);
        shot.transform.position = position;
        shot.transform.localScale = friendly ? new Vector3(0.16f, 0.16f, 0.5f) : new Vector3(0.22f, 0.22f, 0.34f);
        shot.GetComponent<Renderer>().sharedMaterial = material;
        var collider = shot.GetComponent<Collider>();
        if (collider != null) collider.enabled = false;
        return new ShotState { body = shot, velocity = velocity, playerShot = friendly, life = 3f };
    }

    void DamagePlayer(int amount)
    {
        if (playerHitTimer > 0f || gameOver) return;
        hull -= amount;
        playerHitTimer = 0.9f;
        if (hull <= 0)
        {
            hull = 0;
            gameOver = true;
        }
    }

    void LateUpdate()
    {
        if (playerHitTimer > 0f) playerHitTimer -= Time.deltaTime;
    }

    void ResetGame()
    {
        Time.timeScale = 1f;
        if (runtimeRoot != null) Destroy(runtimeRoot);
        enemies.Clear();
        shots.Clear();
        score = 0;
        kills = 0;
        wave = 1;
        hull = 5;
        spawnTimer = 0.8f;
        fireTimer = 0f;
        hazardTimer = 0f;
        playerHitTimer = 0f;
        gameOver = false;
        paused = false;
        runtimeRoot = new GameObject("Runtime Space Shooter");
        player = new GameObject("Player Starfighter");
        player.transform.SetParent(runtimeRoot.transform, false);
        player.transform.position = new Vector3(7.5f, 0.58f, 2.2f);
        MakeShipVisual(player.transform, true);
        initialized = true;
    }

    void BuildMaterials()
    {
        playerMat = MakeMaterial("Player Hull", new Color(0.12f, 0.62f, 0.92f), new Color(0.02f, 0.22f, 0.65f));
        enemyMat = MakeMaterial("Raider Hull", new Color(0.85f, 0.13f, 0.18f), new Color(0.45f, 0.015f, 0.03f));
        accentMat = MakeMaterial("Ion Glow", new Color(0.2f, 0.86f, 1f), new Color(0.08f, 0.65f, 1f));
        playerShotMat = MakeMaterial("Player Pulse", new Color(0.4f, 0.9f, 1f), new Color(0.2f, 0.85f, 1f));
        enemyShotMat = MakeMaterial("Raider Pulse", new Color(1f, 0.35f, 0.1f), new Color(1f, 0.12f, 0.015f));
        asteroidMat = MakeMaterial("Debris", new Color(0.26f, 0.31f, 0.39f), Color.black);
    }

    Material MakeMaterial(string name, Color color, Color emission)
    {
        Shader shader = Shader.Find("Universal Render Pipeline/Lit");
        if (shader == null) shader = Shader.Find("Standard");
        var material = new Material(shader) { name = name };
        if (material.HasProperty("_BaseColor")) material.SetColor("_BaseColor", color);
        if (material.HasProperty("_Color")) material.SetColor("_Color", color);
        if (material.HasProperty("_EmissionColor"))
        {
            material.SetColor("_EmissionColor", emission);
            if (emission.maxColorComponent > 0f) material.EnableKeyword("_EMISSION");
        }
        return material;
    }

    void MakeShipVisual(Transform parent, bool friendly)
    {
        var hullMat = friendly ? playerMat : enemyMat;
        float direction = friendly ? 1f : -1f;
        MakePart(parent, PrimitiveType.Cube, "Fuselage", new Vector3(0f, 0f, 0.08f * direction), new Vector3(0.38f, 0.22f, 1.05f), hullMat);
        MakePart(parent, PrimitiveType.Cube, "Port Wing", new Vector3(-0.54f, -0.015f, -0.04f * direction), new Vector3(0.76f, 0.11f, 0.32f), hullMat);
        MakePart(parent, PrimitiveType.Cube, "Starboard Wing", new Vector3(0.54f, -0.015f, -0.04f * direction), new Vector3(0.76f, 0.11f, 0.32f), hullMat);
        MakePart(parent, PrimitiveType.Sphere, "Cockpit", new Vector3(0f, 0.13f, 0.36f * direction), new Vector3(0.25f, 0.18f, 0.34f), friendly ? accentMat : enemyShotMat);
        MakePart(parent, PrimitiveType.Sphere, "Engine Glow", new Vector3(0f, -0.02f, -0.57f * direction), new Vector3(0.22f, 0.13f, 0.24f), friendly ? playerShotMat : enemyShotMat);
        MakePart(parent, PrimitiveType.Cube, "Tail Fin", new Vector3(0f, 0.13f, -0.28f * direction), new Vector3(0.12f, 0.3f, 0.38f), hullMat);
    }

    GameObject MakePart(Transform parent, PrimitiveType type, string name, Vector3 localPosition, Vector3 scale, Material material)
    {
        var part = GameObject.CreatePrimitive(type);
        part.name = name;
        part.transform.SetParent(parent, false);
        part.transform.localPosition = localPosition;
        part.transform.localScale = scale;
        part.GetComponent<Renderer>().sharedMaterial = material;
        var collider = part.GetComponent<Collider>();
        if (collider != null) collider.enabled = false;
        return part;
    }

    void SpawnBurst(Vector3 position, Material material)
    {
        for (int i = 0; i < 5; i++)
        {
            var spark = GameObject.CreatePrimitive(PrimitiveType.Sphere);
            spark.name = "Ion Spark";
            spark.transform.SetParent(runtimeRoot.transform, true);
            spark.transform.position = position + new Vector3(Random.Range(-0.35f, 0.35f), Random.Range(-0.1f, 0.3f), Random.Range(-0.35f, 0.35f));
            spark.transform.localScale = Vector3.one * Random.Range(0.08f, 0.18f);
            spark.GetComponent<Renderer>().sharedMaterial = material;
            var collider = spark.GetComponent<Collider>();
            if (collider != null) collider.enabled = false;
            Destroy(spark, 0.24f);
        }
    }

    void OnGUI()
    {
        if (!initialized) return;
        var panel = new GUIStyle(GUI.skin.box)
        {
            alignment = TextAnchor.UpperLeft,
            fontSize = 18,
            padding = new RectOffset(18, 18, 14, 14),
            normal = { textColor = Color.white }
        };
        var label = new GUIStyle(GUI.skin.label)
        {
            fontSize = 17,
            fontStyle = FontStyle.Bold,
            normal = { textColor = Color.white }
        };
        GUI.Box(new Rect(18f, 18f, 285f, 150f), GUIContent.none, panel);
        GUI.Label(new Rect(34f, 30f, 260f, 30f), "VOID RUNNER", label);
        GUI.Label(new Rect(34f, 62f, 250f, 25f), "SCORE   " + score.ToString("D6"), label);
        GUI.Label(new Rect(34f, 88f, 250f, 25f), "WAVE   " + wave + "     HULL   " + hull + "/5", label);
        GUI.Label(new Rect(34f, 116f, 255f, 28f), "WASD / ARROWS  MOVE   •   SPACE  FIRE", new GUIStyle(label) { fontSize = 11 });
        GUI.Label(new Rect(Screen.width - 180f, 22f, 160f, 26f), "P  PAUSE", label);

        if (paused && !gameOver)
        {
            GUI.Box(new Rect(Screen.width * 0.5f - 170f, Screen.height * 0.5f - 55f, 340f, 110f), "PAUSED\nPress P to resume", panel);
        }
        if (gameOver)
        {
            GUI.Box(new Rect(Screen.width * 0.5f - 200f, Screen.height * 0.5f - 100f, 400f, 200f), GUIContent.none, panel);
            var center = new GUIStyle(label) { alignment = TextAnchor.MiddleCenter, fontSize = 26 };
            GUI.Label(new Rect(Screen.width * 0.5f - 185f, Screen.height * 0.5f - 85f, 370f, 55f), "SHIP LOST", center);
            GUI.Label(new Rect(Screen.width * 0.5f - 185f, Screen.height * 0.5f - 30f, 370f, 35f), "FINAL SCORE   " + score, new GUIStyle(center) { fontSize = 18 });
            if (GUI.Button(new Rect(Screen.width * 0.5f - 85f, Screen.height * 0.5f + 25f, 170f, 42f), "RESTART  (R)")) ResetGame();
        }
    }
}
