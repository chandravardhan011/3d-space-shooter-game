using System.Collections.Generic;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;
public static class SpaceShooterSceneSetup
{
    const string ScenePath="Assets/_project/Scenes/VoidRunner.unity";
    [MenuItem("Tools/Space Shooter/Create Void Runner Flight Scene")]
    public static void CreateVoidRunnerScene(){
        var scene=EditorSceneManager.NewScene(NewSceneSetup.EmptyScene,NewSceneMode.Single);scene.name="VoidRunner";
        RenderSettings.ambientMode=UnityEngine.Rendering.AmbientMode.Flat;RenderSettings.ambientLight=new Color(.055f,.065f,.085f);RenderSettings.fog=false;
        if(!AssetDatabase.IsValidFolder("Assets/_project/Materials"))AssetDatabase.CreateFolder("Assets/_project","Materials");
        string[] skyNames={"DeepSpaceSkybox","NebulaGalaxySkybox","MarsOrbitSkybox","IcePlanetSkybox","AlienGalaxySkybox"};
        string[] sourcePaths={
            "Assets/Assest store packages/SpaceSkies Free/Skybox_3/Purple_2K_Resolution.mat",
            "Assets/Assest store packages/SpaceSkies Free/Skybox_1/Pink_2K_Resolution.mat",
            "Assets/Assest store packages/SpaceSkies Free/Skybox_1/Pink_2K_Resolution.mat",
            "Assets/Assest store packages/SpaceSkies Free/Skybox_2/Green_2K_Resoution.mat",
            "Assets/Assest store packages/SpaceSkies Free/Skybox_3/Purple_2K_Resolution.mat"};
        float[] exposures={.56f,.64f,.62f,.56f,.52f};
        float[] rotations={150f,35f,220f,0f,82f};
        Color[] tints={new Color(.56f,.70f,.92f),new Color(.86f,.58f,1f),new Color(1f,.50f,.34f),new Color(.52f,.84f,1f),new Color(.48f,1f,.62f)};
        var environmentSkies=new Material[5];
        for(int i=0;i<environmentSkies.Length;i++){
            string path="Assets/_project/Materials/"+skyNames[i]+".mat";
            environmentSkies[i]=AssetDatabase.LoadAssetAtPath<Material>(path);
            if(!environmentSkies[i]){var source=AssetDatabase.LoadAssetAtPath<Material>(sourcePaths[i]);if(source){environmentSkies[i]=new Material(source){name=skyNames[i]};AssetDatabase.CreateAsset(environmentSkies[i],path);}}
            if(environmentSkies[i]){
                environmentSkies[i].SetFloat("_Exposure",exposures[i]);
                environmentSkies[i].SetFloat("_Rotation",rotations[i]);
                if(environmentSkies[i].HasProperty("_Tint"))environmentSkies[i].SetColor("_Tint",tints[i]);
                EditorUtility.SetDirty(environmentSkies[i]);
            }
        }        RenderSettings.skybox=environmentSkies[0];
        var camGo=new GameObject("Flight Camera",typeof(Camera),typeof(AudioListener));camGo.tag="MainCamera";var cam=camGo.GetComponent<Camera>();cam.clearFlags=CameraClearFlags.Skybox;cam.backgroundColor=new Color(.006f,.012f,.035f);cam.fieldOfView=54;cam.nearClipPlane=.08f;cam.farClipPlane=210;cam.allowHDR=true;
        var keyGo=new GameObject("Flight key light",typeof(Light));var key=keyGo.GetComponent<Light>();key.type=LightType.Directional;key.color=new Color(.72f,.84f,1);key.intensity=1.05f;keyGo.transform.rotation=Quaternion.Euler(31,-24,0);
        var director=new GameObject("VOID RUNNER  /  FLIGHT DIRECTOR");var game=director.AddComponent<VoidRunnerFlight>();var so=new SerializedObject(game);so.FindProperty("fighterPrefab").objectReferenceValue=AssetDatabase.LoadAssetAtPath<GameObject>("Assets/Assest store packages/HiRezSpaceshipsCreatorFree/Prefabs/Examples/Example5_Grey.prefab");
        so.FindProperty("flightCamera").objectReferenceValue=cam;
        string[] playerFighters={"Assets/Assest store packages/HiRezSpaceshipsCreatorFree/Prefabs/Examples/Example1_Grey.prefab","Assets/Assest store packages/HiRezSpaceshipsCreatorFree/Prefabs/Examples/Example3_Red.prefab","Assets/Assest store packages/HiRezSpaceshipsCreatorFree/Prefabs/Examples/Example4_Grey.prefab","Assets/Assest store packages/SF_Fighter/SF_Free-Fighter.prefab","Assets/Assest store packages/HiRezSpaceshipsCreatorFree/Prefabs/Examples/Example5_Grey.prefab"};
        string[] opponentShips={"Assets/Assest store packages/HiRezSpaceshipsCreatorFree/Prefabs/Examples/Example1_Red.prefab","Assets/Assest store packages/HiRezSpaceshipsCreatorFree/Prefabs/Examples/Example2_Grey.prefab","Assets/Assest store packages/HiRezSpaceshipsCreatorFree/Prefabs/Examples/Example3_Red.prefab","Assets/Assest store packages/HiRezSpaceshipsCreatorFree/Prefabs/Examples/Example4_Grey.prefab","Assets/Assest store packages/HiRezSpaceshipsCreatorFree/Prefabs/Examples/Example5_Grey.prefab"};
        var playerProp=so.FindProperty("environmentFighters");playerProp.arraySize=playerFighters.Length;for(int i=0;i<playerFighters.Length;i++)playerProp.GetArrayElementAtIndex(i).objectReferenceValue=AssetDatabase.LoadAssetAtPath<GameObject>(playerFighters[i]);var shipChoices=so.FindProperty("shipSelectionPrefabs");shipChoices.arraySize=playerFighters.Length;for(int i=0;i<playerFighters.Length;i++)shipChoices.GetArrayElementAtIndex(i).objectReferenceValue=AssetDatabase.LoadAssetAtPath<GameObject>(playerFighters[i]);
        var opponentProp=so.FindProperty("opponentFighters");opponentProp.arraySize=opponentShips.Length;for(int i=0;i<opponentShips.Length;i++)opponentProp.GetArrayElementAtIndex(i).objectReferenceValue=AssetDatabase.LoadAssetAtPath<GameObject>(opponentShips[i]);
        string audioRoot="Assets/_project/Audio/";
        so.FindProperty("laserClip").objectReferenceValue=AssetDatabase.LoadAssetAtPath<AudioClip>(audioRoot+"laserLarge_000.ogg");
        so.FindProperty("missileClip").objectReferenceValue=AssetDatabase.LoadAssetAtPath<AudioClip>(audioRoot+"thrusterFire_000.ogg");
        so.FindProperty("explosionClip").objectReferenceValue=AssetDatabase.LoadAssetAtPath<AudioClip>(audioRoot+"lowFrequency_explosion_000.ogg");
        so.FindProperty("shieldClip").objectReferenceValue=AssetDatabase.LoadAssetAtPath<AudioClip>(audioRoot+"forceField_000.ogg");
        so.FindProperty("launchClip").objectReferenceValue=AssetDatabase.LoadAssetAtPath<AudioClip>(audioRoot+"engineCircular_000.ogg");
        so.FindProperty("engineClip").objectReferenceValue=AssetDatabase.LoadAssetAtPath<AudioClip>(audioRoot+"spaceEngine_000.ogg");
        so.FindProperty("pickupClip").objectReferenceValue=AssetDatabase.LoadAssetAtPath<AudioClip>(audioRoot+"computerNoise_000.ogg");
        var skiesProp=so.FindProperty("environmentSkyboxes");skiesProp.arraySize=environmentSkies.Length;for(int i=0;i<environmentSkies.Length;i++)skiesProp.GetArrayElementAtIndex(i).objectReferenceValue=environmentSkies[i];so.ApplyModifiedPropertiesWithoutUndo();
        EditorSceneManager.SaveScene(scene,ScenePath);EditorBuildSettings.scenes=new[]{new EditorBuildSettingsScene(ScenePath,true)};Selection.activeGameObject=director;Debug.Log("Void Runner scene created and added to Build Settings: "+ScenePath);
    }

    [MenuItem("Tools/Space Shooter/Upgrade Existing Game Scene")]
    public static void UpgradeExistingScene(){
        var scene=EditorSceneManager.OpenScene(ScenePath,OpenSceneMode.Single);
        var game=Object.FindFirstObjectByType<VoidRunnerFlight>();
        if(!game){Debug.LogError("VoidRunnerFlight was not found in "+ScenePath);return;}
        string[] sources={
            "Assets/Assest store packages/SpaceSkies Free/Skybox_3/Purple_2K_Resolution.mat",
            "Assets/Assest store packages/SpaceSkies Free/Skybox_1/Pink_2K_Resolution.mat",
            "Assets/Assest store packages/SpaceSkies Free/Skybox_1/Pink_2K_Resolution.mat",
            "Assets/Assest store packages/SpaceSkies Free/Skybox_2/Green_2K_Resoution.mat",
            "Assets/Assest store packages/SpaceSkies Free/Skybox_3/Purple_2K_Resolution.mat"};
        string[] names={"DeepSpaceSkybox","NebulaGalaxySkybox","MarsOrbitSkybox","IcePlanetSkybox","AlienGalaxySkybox"};
        Color[] tints={new Color(.56f,.70f,.92f),new Color(.86f,.58f,1f),new Color(1f,.50f,.34f),new Color(.52f,.84f,1f),new Color(.48f,1f,.62f)};
        float[] exposures={.56f,.64f,.62f,.56f,.52f};
        float[] rotations={150f,35f,220f,0f,82f};
        var skies=new Material[5];
        for(int i=0;i<5;i++){
            string path="Assets/_project/Materials/"+names[i]+".mat";
            skies[i]=AssetDatabase.LoadAssetAtPath<Material>(path);
            if(!skies[i]){
                var source=AssetDatabase.LoadAssetAtPath<Material>(sources[i]);
                if(!source){Debug.LogError("Missing sky source: "+sources[i]);return;}
                skies[i]=new Material(source){name=names[i]};
                AssetDatabase.CreateAsset(skies[i],path);
            }
            if(skies[i].HasProperty("_Tint"))skies[i].SetColor("_Tint",tints[i]);
            if(skies[i].HasProperty("_Exposure"))skies[i].SetFloat("_Exposure",exposures[i]);
            if(skies[i].HasProperty("_Rotation"))skies[i].SetFloat("_Rotation",rotations[i]);
            EditorUtility.SetDirty(skies[i]);
        }
        string[] ships={
            "Assets/Assest store packages/HiRezSpaceshipsCreatorFree/Prefabs/Examples/Example1_Grey.prefab",
            "Assets/Assest store packages/HiRezSpaceshipsCreatorFree/Prefabs/Examples/Example3_Red.prefab",
            "Assets/Assest store packages/HiRezSpaceshipsCreatorFree/Prefabs/Examples/Example4_Grey.prefab",
            "Assets/Assest store packages/SF_Fighter/SF_Free-Fighter.prefab",
            "Assets/Assest store packages/HiRezSpaceshipsCreatorFree/Prefabs/Examples/Example5_Grey.prefab"};
        string[] enemies={
            "Assets/Assest store packages/HiRezSpaceshipsCreatorFree/Prefabs/Examples/Example1_Red.prefab",
            "Assets/Assest store packages/HiRezSpaceshipsCreatorFree/Prefabs/Examples/Example2_Grey.prefab",
            "Assets/Assest store packages/HiRezSpaceshipsCreatorFree/Prefabs/Examples/Example3_Red.prefab",
            "Assets/Assest store packages/HiRezSpaceshipsCreatorFree/Prefabs/Examples/Example4_Grey.prefab",
            "Assets/Assest store packages/HiRezSpaceshipsCreatorFree/Prefabs/Examples/Example5_Grey.prefab"};
        var so=new SerializedObject(game);
        SetPrefabs(so,"environmentFighters",ships);
        SetPrefabs(so,"shipSelectionPrefabs",ships);
        SetPrefabs(so,"opponentFighters",enemies);
        var skyProp=so.FindProperty("environmentSkyboxes");
        skyProp.arraySize=skies.Length;
        for(int i=0;i<skies.Length;i++)skyProp.GetArrayElementAtIndex(i).objectReferenceValue=skies[i];
        so.ApplyModifiedPropertiesWithoutUndo();
        RenderSettings.skybox=skies[0];
        EditorSceneManager.MarkSceneDirty(scene);
        EditorSceneManager.SaveScene(scene,ScenePath);
        EditorBuildSettings.scenes=new[]{new EditorBuildSettingsScene(ScenePath,true)};
        Debug.Log("3D SPACE SHOOTER GAME upgraded: five themes and five selectable 3D ships.");
    }
    static void SetPrefabs(SerializedObject so,string propertyName,string[] paths){
        var array=so.FindProperty(propertyName);
        array.arraySize=paths.Length;
        for(int i=0;i<paths.Length;i++){
            var prefab=AssetDatabase.LoadAssetAtPath<GameObject>(paths[i]);
            if(!prefab)Debug.LogWarning("Missing model: "+paths[i]);
            array.GetArrayElementAtIndex(i).objectReferenceValue=prefab;
        }
    }}

