using System.Linq;
using UnityEditor;
using UnityEditor.PackageManager;
using UnityEditor.PackageManager.Requests;
using UnityEngine;

public static class TilemapPackageInstaller
{
    static AddRequest request;
    static double deadline;
    [MenuItem("Tools/Tilemap/Install RuleTile Package")]
    public static void Install()
    {
        request = Client.Add("com.unity.2d.tilemap.extras");
        deadline = EditorApplication.timeSinceStartup + 600;
        EditorApplication.update += Poll;
    }
    static void Poll()
    {
        if (!request.IsCompleted)
        {
            if (EditorApplication.timeSinceStartup > deadline) { EditorApplication.update -= Poll; Debug.LogError("Tilemap extras install timed out."); return; }
            return;
        }
        EditorApplication.update -= Poll;
        if (request.Status == StatusCode.Success) { Debug.Log("Installed " + request.Result.name + "@" + request.Result.version);  }
        else { Debug.LogError(request.Error == null ? "Tilemap extras install failed." : request.Error.message);  }
    }
}


