using System.Collections.Generic;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.Tilemaps;

public static class SpaceStationTilemapSetup
{
    const string Root = "Assets/_project/Tilemap";
    const string Prefabs = Root + "/Prefabs";
    const string Tiles = Root + "/RuleTiles";
    const string Materials = Root + "/Materials";
    const string ScenePath = "Assets/_project/Scenes/SpaceStationTilemap.unity";

    [MenuItem("Tools/Tilemap/Build Space Station Level")]
    public static void Build()
    {
        EnsureFolder("Assets/_project", "Tilemap");
        EnsureFolder(Root, "Prefabs");
        EnsureFolder(Root, "RuleTiles");
        EnsureFolder(Root, "Materials");

        var deckMaterial = MakeMaterial("StationDeck_Mat", new Color(0.095f, 0.16f, 0.23f), new Color(0.02f, 0.11f, 0.17f));
        var hazardMaterial = MakeMaterial("StationHazard_Mat", new Color(0.95f, 0.34f, 0.07f), new Color(0.95f, 0.12f, 0.015f));
        var trimMaterial = MakeMaterial("StationTrim_Mat", new Color(0.14f, 0.52f, 0.67f), new Color(0.02f, 0.3f, 0.5f));
        var deckPrefab = MakeCubePrefab("StationDeckTile", deckMaterial, new Vector3(0.96f, 0.16f, 0.96f));
        var hazardPrefab = MakeCubePrefab("StationHazardTile", hazardMaterial, new Vector3(0.96f, 0.16f, 0.96f));
        var trimPrefab = MakeCubePrefab("StationTrimTile", trimMaterial, new Vector3(0.96f, 0.2f, 0.96f));

        var deckRule = MakeRuleTile("StationDeck_RuleTile", deckPrefab, true);
        var hazardRule = MakeRuleTile("StationHazard_RuleTile", hazardPrefab, false);
        var trimRule = MakeRuleTile("StationTrim_RuleTile", trimPrefab, false);

        var scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
        scene.name = "SpaceStationTilemap";

        var gridObject = new GameObject("Space Station Grid (X-Z Plane)");
        var grid = gridObject.AddComponent<Grid>();
        grid.cellSize = Vector3.one;
        grid.cellSwizzle = GridLayout.CellSwizzle.XZY;

        var deckObject = new GameObject("Station Deck RuleTilemap");
        deckObject.transform.SetParent(gridObject.transform, false);
        var tilemap = deckObject.AddComponent<Tilemap>();
        deckObject.AddComponent<TilemapRenderer>();

        const int width = 16;
        const int height = 16;
        for (int z = 0; z < height; z++)
        for (int x = 0; x < width; x++)
        {
            var cell = new Vector3Int(x, z, 0);
            tilemap.SetTile(cell, deckRule);

            bool cornerTrim = (x == 0 || x == width - 1) && (z == 0 || z == height - 1);
            bool railTrim = (z == 1 || z == height - 2) && x >= 3 && x <= width - 4 && x % 3 == 0;
            if (cornerTrim || railTrim)
                tilemap.SetTile(cell, trimRule);

            bool hazard = (z == 4 || z == 11) && x >= 5 && x <= 10;
            if (hazard)
                tilemap.SetTile(cell, hazardRule);
        }
        tilemap.RefreshAllTiles();

        AddRail("North Safety Rail", new Vector3(7.5f, 0.62f, 15.65f), new Vector3(16f, 1.05f, 0.22f), trimMaterial);
        AddRail("South Safety Rail", new Vector3(7.5f, 0.62f, -0.65f), new Vector3(16f, 1.05f, 0.22f), trimMaterial);
        AddRail("West Safety Rail", new Vector3(-0.65f, 0.62f, 7.5f), new Vector3(0.22f, 1.05f, 16f), trimMaterial);
        AddRail("East Safety Rail", new Vector3(15.65f, 0.62f, 7.5f), new Vector3(0.22f, 1.05f, 16f), trimMaterial);

        var beacon = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
        beacon.name = "Navigation Beacon";
        beacon.transform.position = new Vector3(7.5f, 0.46f, 7.5f);
        beacon.transform.localScale = new Vector3(1.25f, 0.18f, 1.25f);
        beacon.GetComponent<Renderer>().sharedMaterial = trimMaterial;

        var start = GameObject.CreatePrimitive(PrimitiveType.Cube);
        start.name = "Spawn Marker";
        start.transform.position = new Vector3(2.5f, 0.35f, 2.5f);
        start.transform.localScale = new Vector3(1.8f, 0.12f, 1.8f);
        start.GetComponent<Renderer>().sharedMaterial = trimMaterial;

        var lightObject = new GameObject("Station Key Light");
        var light = lightObject.AddComponent<Light>();
        light.type = LightType.Directional;
        light.intensity = 1.2f;
        light.color = new Color(0.72f, 0.86f, 1f);
        lightObject.transform.rotation = Quaternion.Euler(48f, -28f, 0f);

        var cameraObject = new GameObject("Station Camera");
        var camera = cameraObject.AddComponent<Camera>();
        camera.clearFlags = CameraClearFlags.SolidColor;
        camera.backgroundColor = new Color(0.012f, 0.025f, 0.055f);
        camera.fieldOfView = 54f;
        camera.nearClipPlane = 0.1f;
        camera.farClipPlane = 300f;
        cameraObject.tag = "MainCamera";
        cameraObject.transform.position = new Vector3(19f, 20f, -15f);
        cameraObject.transform.LookAt(new Vector3(7.5f, 0f, 7.5f));

        RenderSettings.ambientMode = UnityEngine.Rendering.AmbientMode.Flat;
        RenderSettings.ambientLight = new Color(0.22f, 0.28f, 0.38f);
        RenderSettings.ambientIntensity = 1f;
        RenderSettings.fog = true;
        RenderSettings.fogColor = new Color(0.025f, 0.045f, 0.09f);
        RenderSettings.fogMode = FogMode.Linear;
        RenderSettings.fogStartDistance = 35f;
        RenderSettings.fogEndDistance = 80f;

        EditorSceneManager.MarkSceneDirty(scene);
        EditorSceneManager.SaveScene(scene, ScenePath);
        var buildScenes = new List<EditorBuildSettingsScene>(EditorBuildSettings.scenes);
        if (!buildScenes.Exists(entry => entry.path == ScenePath))
        {
            buildScenes.Add(new EditorBuildSettingsScene(ScenePath, true));
            EditorBuildSettings.scenes = buildScenes.ToArray();
        }
        AssetDatabase.SaveAssets();
        AssetDatabase.Refresh();
        Selection.activeGameObject = gridObject;
        Debug.Log("Built the 16 x 16 X-Z space station RuleTile level at " + ScenePath);
    }

    static RuleTile MakeRuleTile(string name, GameObject output, bool fullSet)
    {
        string path = Tiles + "/" + name + ".asset";
        var tile = AssetDatabase.LoadAssetAtPath<RuleTile>(path);
        if (tile == null)
        {
            tile = ScriptableObject.CreateInstance<RuleTile>();
            AssetDatabase.CreateAsset(tile, path);
        }

        tile.m_DefaultGameObject = output;
        tile.m_DefaultColliderType = Tile.ColliderType.None;
        tile.m_DefaultSprite = null;
        tile.m_TilingRules.Clear();

        if (fullSet)
        {
            // Eight-neighbour rotated patterns. Zero means Any; one means this RuleTile.
            int[][] patterns =
            {
                new[] {1,1,1,1,1,1,1,1},
                new[] {0,1,0,1,1,0,1,0},
                new[] {0,0,0,1,0,1,1,1},
                new[] {1,1,1,1,0,0,1,0},
                new[] {1,0,1,0,1,0,0,0},
                new[] {1,1,1,0,1,0,0,0},
                new[] {0,1,0,1,0,1,0,1},
                new[] {1,0,1,1,0,1,0,0},
                new[] {1,0,1,0,1,0,1,0},
                new[] {0,1,0,0,1,0,1,0},
                new[] {0,0,0,1,0,0,1,1},
                new[] {1,0,0,0,1,1,0,1},
                new[] {1,0,1,0,1,0,0,1},
                new[] {0,0,0,0,1,0,1,0},
                new[] {0,0,0,0,0,0,0,0}
            };
            foreach (var pattern in patterns)
                tile.m_TilingRules.Add(MakeRule(output, pattern, RuleTile.TilingRuleOutput.Transform.Rotated));
        }
        else
        {
            tile.m_TilingRules.Add(MakeRule(output, new[] { 0, 1, 0, 0, 0, 0, 0, 0 }, RuleTile.TilingRuleOutput.Transform.Rotated));
        }

        EditorUtility.SetDirty(tile);
        return tile;
    }

    static RuleTile.TilingRule MakeRule(GameObject output, int[] neighbors, RuleTile.TilingRuleOutput.Transform transform)
    {
        var rule = new RuleTile.TilingRule();
        rule.m_Sprites = new Sprite[] { null };
        rule.m_GameObject = output;
        rule.m_Output = RuleTile.TilingRuleOutput.OutputSprite.Single;
        rule.m_RuleTransform = transform;
        rule.m_Neighbors = new List<int>(neighbors);
        return rule;
    }

    static Material MakeMaterial(string name, Color color, Color emission)
    {
        string path = Materials + "/" + name + ".mat";
        var material = AssetDatabase.LoadAssetAtPath<Material>(path);
        if (material == null)
        {
            Shader shader = Shader.Find("Universal Render Pipeline/Lit");
            if (shader == null) shader = Shader.Find("Standard");
            material = new Material(shader);
            AssetDatabase.CreateAsset(material, path);
        }
        if (material.HasProperty("_BaseColor")) material.SetColor("_BaseColor", color);
        if (material.HasProperty("_Color")) material.SetColor("_Color", color);
        if (material.HasProperty("_EmissionColor"))
        {
            material.SetColor("_EmissionColor", emission);
            material.EnableKeyword("_EMISSION");
        }
        EditorUtility.SetDirty(material);
        return material;
    }

    static GameObject MakeCubePrefab(string name, Material material, Vector3 scale)
    {
        string path = Prefabs + "/" + name + ".prefab";
        var prefab = AssetDatabase.LoadAssetAtPath<GameObject>(path);
        if (prefab != null) return prefab;

        var cube = GameObject.CreatePrimitive(PrimitiveType.Cube);
        cube.name = name;
        cube.transform.localScale = scale;
        cube.GetComponent<Renderer>().sharedMaterial = material;
        prefab = PrefabUtility.SaveAsPrefabAsset(cube, path);
        Object.DestroyImmediate(cube);
        return prefab;
    }

    static void AddRail(string name, Vector3 position, Vector3 scale, Material material)
    {
        var rail = GameObject.CreatePrimitive(PrimitiveType.Cube);
        rail.name = name;
        rail.transform.position = position;
        rail.transform.localScale = scale;
        rail.GetComponent<Renderer>().sharedMaterial = material;
    }

    static void EnsureFolder(string parent, string name)
    {
        string path = parent + "/" + name;
        if (!AssetDatabase.IsValidFolder(path)) AssetDatabase.CreateFolder(parent, name);
    }
}

